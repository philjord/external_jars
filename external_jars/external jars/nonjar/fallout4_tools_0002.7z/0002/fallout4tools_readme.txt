Random Fallout 4 Tools v0002
by Ian Patterson (ianpatt+f4se [at] gmail [dot] com)

These are some assorted command line tools for Fallout 4 that I think might be useful for other people. As more things are written I'll package and upload them.

[ ba2extract ]

Extracts files from a .ba2 archive. Repacking is not supported, but there is enough information in the source code to write a repacker. I think the engine actually might still have some .bsa support in it, but this is untested.

There are two types of ba2 archives: general, and texture. General archives can contain anything, while texture archives are optimized for storing textures. There is no significant size advantage when comparing the two, but texture archives store textures in a more intelligent way that is friendlier to the runtime texture streamer. When reading a DDS file, finding the lower resolution textures requires seeking to, and therefore decompressing most of the file. This is inefficient, because in most cases you will care about the lower resolution mips first, when the object is off in the distance. Texture archives store any mips higher than 256x256 in their own separate blocks, while the 256x256 and below are all in their own block.

Please note that the values in the DDS header are not present in the original texture archive, and were chosen for compatibility rather than accuracy. Color textures are accurate, but DXGI_FORMAT_BC5_UNORM (normal maps) and DXGI_FORMAT_BC7_UNORM are definitely wrong. Add the -atifourcc command line option to use the ATI2 format in the DDS header for normal maps, giving you a file that you can open in nvidia's photoshop dds plugin. I have not tested if these files will work in the game - the game expects a DX10-style header with DXGI_FORMAT_BC5_UNORM explicitly specified.

Quick licensing info:

Anything deriving from this must also have its source available, and may not be used for profit in any way. Redistribution is not allowed. Learn, don't copy.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.