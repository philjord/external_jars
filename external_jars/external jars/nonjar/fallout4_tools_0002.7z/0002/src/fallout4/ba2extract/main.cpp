#include "common/IFileStream.h"
#include "Archive.h"

IDebugLog gLog("ba2extract.log");

int main(int argc, char ** argv)
{
	if(argc < 3)
	{
		_ERROR("%s: usage [src] [dst] (options)", argv[0]);
		_ERROR("options:");
		_ERROR("  -atifourcc - use ATI2 fourcc for normal maps instead of DXT5.");
		_ERROR("               known to work with nvidia photoshop plugin.");
		_ERROR("               currently untested with the game.");

		return 1;
	}

	const char * srcPath = argv[1];
	const char * dstRoot = argv[2];
	bool useATIFourCC = false;

	for(UInt32 i = 3; i < argc; i++)
	{
		const char * arg = argv[i];

		if(!_stricmp(arg, "-atifourcc"))
			useATIFourCC = true;
		else
		{
			_ERROR("unhandled option (%s)", arg);
		}
	}

	IFileStream src;
	if(src.Open(srcPath))
	{
		Archive archive;

		if(useATIFourCC) archive.UseATIFourCC();

		if(archive.Read(&src))
		{
			_MESSAGE("read ok");

			archive.Extract(dstRoot);
		}
		else
		{
			_MESSAGE("error reading archive", srcPath);
		}
	}
	else
	{
		_MESSAGE("couldn't open %s", srcPath);
	}
}
